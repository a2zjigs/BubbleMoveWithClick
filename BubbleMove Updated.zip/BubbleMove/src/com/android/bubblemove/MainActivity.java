package com.android.bubblemove;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnTouchListener,OnClickListener {
	int j = 0;
	int k = 1;
	int i = 0;
	int f = 1;
	int m = 0;

	TextView bImg;
	TextView b1Img;
	TextView b2Img;
	TextView b3Img;

	ImageView bubbleImg;
	RelativeLayout rlid;
	LinearLayout mItemLayoutRuntime;
	RelativeLayout.LayoutParams params;
	RelativeLayout.LayoutParams params1;
	RelativeLayout.LayoutParams params2;
	RelativeLayout.LayoutParams params3;

	private Timer myTimer;
	Button B1;

	int height;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		rlid = (RelativeLayout) findViewById(R.id.rlidd);
		params = new RelativeLayout.LayoutParams(100,100);
		params1 = new RelativeLayout.LayoutParams(100, 100);
		params2 = new RelativeLayout.LayoutParams(100,100);
		params3 = new RelativeLayout.LayoutParams(100, 100);

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		 height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		
		params.leftMargin = 10;
		params.topMargin = -100;

		params1.leftMargin = 100;
		params1.topMargin = -180;
		
		params2.leftMargin = 180;
		params2.topMargin = -120;

		params3.leftMargin = 300;
		params3.topMargin = -190;
		
//		params.leftMargin = 10;
//		params1.leftMargin = 100;
//		params2.leftMargin = 180;
//		params3.leftMargin = 300;

		bImg = new TextView(getApplicationContext());
		bImg.setText(" " +k);

		b1Img = new TextView(getApplicationContext());
		b1Img.setText(" " + k);
		

		b2Img = new TextView(getApplicationContext());
		b2Img.setText(" " + k);
		
		b3Img = new TextView(getApplicationContext());
		b3Img.setText(" " + k);
		

		bImg.setBackgroundResource(R.drawable.bubble);
		rlid.addView(bImg);
		bImg.setLayoutParams(params);
		bImg.setWidth(200);
		bImg.setTextSize(9);
		bImg.setGravity(Gravity.CENTER);
		bImg.setOnClickListener(this);

		b1Img.setBackgroundResource(R.drawable.bubble);
		rlid.addView(b1Img);
		b1Img.setLayoutParams(params1);
		b1Img.setWidth(200);
		b1Img.setTextSize(9);
		b1Img.setGravity(Gravity.CENTER);
		b1Img.setOnClickListener(this);
		
		b2Img.setBackgroundResource(R.drawable.bubble);
		rlid.addView(b2Img);
		b2Img.setLayoutParams(params2);
		b2Img.setWidth(200);
		b2Img.setTextSize(9);
		b2Img.setGravity(Gravity.CENTER);
		b2Img.setOnClickListener(this);
		
		b3Img.setBackgroundResource(R.drawable.bubble);
		rlid.addView(b3Img);
		b3Img.setLayoutParams(params3);
		b3Img.setWidth(200);
		b3Img.setTextSize(9);
		b3Img.setGravity(Gravity.CENTER);
		b3Img.setOnClickListener(this);

		B1 = (Button) findViewById(R.id.button1);

	}

	public boolean onTouch(View view, MotionEvent event) {
		//BubMethod();
		Toast.makeText(this, "Clicked", Toast.LENGTH_LONG).show();
		return true;
	}

	public void sM(View view) {

		myTimer = new Timer();
		myTimer.schedule(new TimerTask() {

			@Override
			public void run() {
				i = i + f;
				m = m + f;

				if (m > height) {
					m = 0;
					i = 0;
					k = k + 1;

					params.topMargin = -60;
					params1.topMargin = -180;
//					params1.leftMargin=150;
					
//					params2.leftMargin=170;
//					params3.leftMargin=220;
					params2.topMargin = -190;
					params3.topMargin = -250;
					
					params.leftMargin = 10;
					params1.leftMargin = 100;
					params2.leftMargin = 200;
					params3.leftMargin = 320;
				} else {
					params.topMargin = -60 + m;
					params1.topMargin = -180 + m;
//					params1.leftMargin=150;
					
//					params2.leftMargin=170;
//					params3.leftMargin=220;
					
					params2.topMargin = -190+m;
					params3.topMargin = -250+m;
					
					params.leftMargin = 10;
					params1.leftMargin = 100;
					params2.leftMargin = 200;
					params3.leftMargin = 320;
				}

//				if (i > 500) {
//
//					params.topMargin = -60;
//					// bImg.setText(" "+k);
//				} else {
//					params.topMargin = -60 + i;
//				}
//
//				if (j == 0) {
//					params.leftMargin = 50 + f;
//					j = 1;
//				} else if (j == 1) {
//					params.leftMargin = 50 - f;
//					j = 2;
//				} else if (j == 2) {
//					params.leftMargin = 50 - f;
//					j = 3;
//				} else {
//					params.leftMargin = 50 + f;
//					j = 0;
//				}

				rlid.post(new Runnable() {

					public void run() {
						bImg.setLayoutParams(params);
						b1Img.setLayoutParams(params1);
						b2Img.setLayoutParams(params2);
						b3Img.setLayoutParams(params3);
						
						bImg.setText("photos  " + k);
						b1Img.setText("videos  " + k + 1);
						b2Img.setText("Blog  " + k);
						b3Img.setText("funzon  " + k);
					}
				});

			}

		}, 0, 20);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Toast.makeText(this, "Clicked", Toast.LENGTH_LONG).show();
	}

}
